# Shared tenant runtime

The canonical source for Node integration loading, managed-identity Key Vault
access, company context, topic parsing and Redis job leases lives here. Services
install a versioned local npm archive from `vendor/`, so their private repositories
and Docker contexts remain independently buildable without a package registry.
After changes, run `python3 scripts/vendor-tenant-runtime.py`, update each service
lockfile with `npm install ./vendor/irvine-tenant-runtime-0.1.0.tgz`, and run
`python3 scripts/vendor-tenant-runtime.py --check`. Do not edit the vendored archive.

Required shared infrastructure: database connectivity, `REDIS_URL`, and
`KEY_VAULT_ALLOWED_HOSTS` (comma-separated vault hostnames). `AZURE_CLIENT_ID` is
optional for a user-assigned managed identity. There is no client-secret,
developer-credential, environment-password or stale-secret fallback. Secrets are
JSON objects in company/kind-named Key Vault secrets, referenced by ready rows in
`tenant_integration`. Cache lifetime is three minutes, maximum five, with a new
cache identity for each row/config/reference revision. Disabled rows fail closed.

Job names and company IDs scope Redis leases. Ownership is renewed and checked
before effects; loss aborts the job. Completion markers also suppress a second
replica starting the same scheduled slot after the first has finished. Locks
prevent duplicate healthy replicas, not exactly-once external effects across
process crashes or network partitions; retries of irreversible effects require
provider idempotency. Reading writers use stable event IDs or existing duplicate
checks. No lock is bypassed when Redis is unavailable.

R-08 database access uses `companyPool(new Pool(config))`. Inside `withCompany`,
queries run with transaction-local `app.company_id` on the same checked-out
connection. Outside a company context, protected tables return no rows. Explicit
transactions must use `await db.connect()`; releasing an unfinished transaction
removes that connection from the pool. A transaction cannot switch companies.

The runtime login must have neither BYPASSRLS/superuser privileges nor membership
in a privileged/owner role. `db.verify()` checks this and the UI's R-08 policy
migration before a service starts. Use maintenance credentials only for migrations
and explicitly approved fleet jobs/imports, never as a fallback for runtime reads.

Shared-hub device resolution queries only the explicitly approved companies, one
at a time. The UI migration supplies the narrow global device-uniqueness function.
Mobile API uses Prisma interactive transactions with the same local setting.

Run `python scripts/test_service_row_security.py` from the parent repository to
exercise actual UI migrations, all five service RLS suites and service startup.
Standalone checkouts are supported with `--ui-root` and `--services-root`.
The migration/credential rollout guide is
`frontend/irvine-ui/docs/security/company-row-security.md` in the UI repository.
