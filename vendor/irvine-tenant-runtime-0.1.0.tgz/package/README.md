# Shared tenant runtime

The canonical source for Node integration loading, managed-identity Key Vault
access, company context, topic parsing and Redis job leases lives here. Services
install a versioned local npm archive from `vendor/`, so their private repositories
and Docker contexts remain independently buildable without a package registry.
After changes, run `python3 scripts/vendor-tenant-runtime.py`, update each service
lockfile with `npm install ./vendor/irvine-tenant-runtime-0.1.0.tgz`, and run
`python3 scripts/vendor-tenant-runtime.py --check`. Do not edit the vendored archive.

Required shared infrastructure: database connectivity, `REDIS_URL`, and
`KEY_VAULT_ALLOWED_HOSTS` (comma-separated vault hostnames). `AZURE_CLIENT_ID` is
optional for a user-assigned managed identity. There is no client-secret,
developer-credential, environment-password or stale-secret fallback. Secrets are
JSON objects in company/kind-named Key Vault secrets, referenced by ready rows in
`tenant_integration`. Cache lifetime is three minutes, maximum five, with a new
cache identity for each row/config/reference revision. Disabled rows fail closed.

Job names and company IDs scope Redis leases. Ownership is renewed and checked
before effects; loss aborts the job. Completion markers also suppress a second
replica starting the same scheduled slot after the first has finished. Locks
prevent duplicate healthy replicas, not exactly-once external effects across
process crashes or network partitions; retries of irreversible effects require
provider idempotency. Reading writers use stable event IDs or existing duplicate
checks. No lock is bypassed when Redis is unavailable.
